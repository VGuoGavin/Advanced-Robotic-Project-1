close all
clear
global Link

%% Forwards and Backwards part
XX = [];    %设为矩阵
YY = [];  
ZZ = [];  
XX_real = [];  
YY_real = [];  
ZZ_real = [];  
error = [];  
num = 1;
% for p1 = 0 :-10:-95
%     for p2 = 0 :-2:-95 
%         for p3 = 90 :-2:-95
%             disp("target:")
%             disp([100, p2, p3])
%             Trajectory = 200 * Locus(100, p2, p3, 1);
% 
%             XX(num) = Trajectory(1);
%             YY(num) = Trajectory(2);
%             ZZ(num) = Trajectory(3);
% 
%             XX_real(num) = 100;
%             YY_real(num) = p2;
%             ZZ_real(num) = p3;
%             plot3(XX, YY, ZZ, 'r.');
%             hold on;
%             %plot3(XX_real, YY_real, ZZ_real, 'b.');
%             error(num)  = sqrt( (XX(num)-XX_real(num))^2 + (YY(num)-YY_real(num))^2+ (ZZ(num)-ZZ_real(num))^2  );
% 
%             num = num+1;
% %             if num == 500
% %                 break;
% %             end
%         end
% %         if num == 500
% %             break;
% %         end
%         mid_point(100, p2, p3, 100, 0, 90);
% 
%     end
% %     if num == 500
% %         break;
% %     end
% end
% figure
% plot(1:num,error);
% hold on
% title("error")
%% Jacobian part

close all
clear all
speed = 0.1;
current_q = [pi/2, 0, 0, 0, 0, 0];
area_num = 1;
q_end = Character_F(current_q, area_num, speed);
next_p = [0;  0; 165; 20; 300; 10];
q_end = current_2_next(q_end,next_p,0.12, 0); 

